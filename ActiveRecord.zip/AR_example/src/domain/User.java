/**
 * 
 */
package domain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.print.attribute.standard.RequestingUserName;
import com.mysql.jdbc.Driver;

/**
 * @author Denys Smile
 *
 */
public class User implements Resourses {
	private Integer id;
	private String name;
	private Integer userCategory_ID;
	
	public User (){}
	public User (String name, Integer userCategory_ID){
		this.name = name;
		this.userCategory_ID = userCategory_ID;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getUserCategory_ID() {
		return userCategory_ID;
	}
	public void setUserCategory_ID(Integer userCategory_ID) {
		this.userCategory_ID = userCategory_ID;
	}
	@SuppressWarnings("finally")
	public void retrieveAll() {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM mydb.user;");
			while(rs.next()) {
				int id = rs.getInt("ID");
				int userCategory_ID = rs.getInt("UserCategory_ID");
				String name = rs.getString("Name");
				
				System.out.print("ID: "+id+", ");
				System.out.print("Name: "+name+", ");
				System.out.println("User category id: "+userCategory_ID);
			}
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();
				rs.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}
	}
	public void retrieveById(Integer id) {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			rs = st.executeQuery("SELECT id, Name, userCategory_ID FROM mydb.user "
								+ "WHERE id ="+id+";");
			while (rs.next()) {
				int iden = rs.getInt("ID");
				int userCategory_ID = rs.getInt("UserCategory_ID");
				String name = rs.getString("Name");				
				System.out.println("ID: "+iden+", ");
				System.out.println("Name: "+name+", ");
				System.out.println("User category id: "+userCategory_ID);
				System.out.println();
			}
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();
				rs.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}
	}
	public void update(String name, Integer id) {
		Connection conn = null;
		Statement st = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			st.executeUpdate("UPDATE mydb.user SET name = '"+name
							+ "' WHERE id="+id+";");
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}	
	}
	public void delete(Integer id) {
		Connection conn = null;
		Statement st = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			st.executeUpdate("DELETE FROM mydb.user WHERE id="+id+";");
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();

			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}	
	}
	public void deleteAll() {
		Connection conn = null;
		Statement st = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			st.executeUpdate("DELETE * FROM mydb.user;");
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}
	}
	public void create(Integer index) {
		Connection conn = null;
		Statement st = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			st.executeUpdate("INSERT INTO mydb.user (name, userCategory_ID) "
							+ "VALUES ('"+getName()+"','"+index+"');");
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}
	}
	@SuppressWarnings("finally")
	public Integer findByName() {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		Integer iden =-1;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			rs = st.executeQuery("SELECT id FROM mydb.user "
								+ "WHERE name ='"+getName()+"';");
			while (rs.next()) {
				iden = rs.getInt("ID");
			}
			rs.close();
			return iden;
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
			return iden;
		}
	}
}
