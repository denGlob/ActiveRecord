/**
 * 
 */
package domain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author Denys Smile
 *
 */
public class Message implements Resourses {
	private String text;
	private Integer toUser;
	private Integer fromUser;
	private Integer id;
	public Message (){}
	public Message (String text, Integer toUser, Integer fromUser) {
		this.text = text;
		this.toUser = toUser;
		this.fromUser = fromUser;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public Integer getToUser() {
		return toUser;
	}
	public void setToUser(Integer toUser) {
		this.toUser = toUser;
	}
	public Integer getFromUser() {
		return fromUser;
	}
	public void setFromUser(Integer fromUser) {
		this.fromUser = fromUser;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	@SuppressWarnings("finally")
	public void retrieveAll() {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM mydb.Message;");
			while(rs.next()) {
				int id = rs.getInt("ID");
				int toUser = rs.getInt("toUser");
				int fromUser = rs.getInt("fromUser");
				String name = rs.getString("Text");
				
				System.out.print("ID: "+id+", ");
				System.out.print("Text: "+name+", ");
				System.out.print("From user: "+fromUser+", ");
				System.out.println("To user: "+toUser);
			}
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();
				rs.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}
	}
	public void retrieveById(Integer id) {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			rs = st.executeQuery("SELECT id, Name FROM mydb.Message "
								+ "WHERE id ="+id+";");
			int iden = rs.getInt("ID");
			int toUser = rs.getInt("toUser");
			int fromUser = rs.getInt("fromUser");
			String name = rs.getString("Text");
			
			System.out.print("ID: "+id+", ");
			System.out.print("Text: "+name+", ");
			System.out.print("From user: "+fromUser+", ");
			System.out.println("To user: "+toUser);
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();
				rs.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}
	}
	public void update(Integer id, String text, Integer user1, Integer user2) {
		Connection conn = null;
		Statement st = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			st.executeUpdate("UPDATE mydb.Message SET text='"+text+"', "
					+ "toUser="+user1+", fromUser="+user2+" WHERE id="
							+id+";");
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}	
	}
	public void delete(Integer id) {
		Connection conn = null;
		Statement st = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			st.executeUpdate("DELETE FROM mydb.Message WHERE id="+id+";");
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();

			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}	
	}
	public void deleteAll() {
		Connection conn = null;
		Statement st = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			st.executeUpdate("DELETE * FROM mydb.Message; ");
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}
	}
	public void create() {
		Connection conn = null;
		Statement st = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			st.executeUpdate("INSERT INTO mydb.Message (text, toUser, fromUser) "
							+ "VALUES ('"+getText()+"','"+getToUser()+"','"+getFromUser()+"');");
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}
	}
}
