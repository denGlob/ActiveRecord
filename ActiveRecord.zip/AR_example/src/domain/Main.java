/**
 * 
 */
package domain;

/**
 * @author Denys Smile
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserCategory userCat1 = new UserCategory("adresat");
		UserCategory userCat2 = new UserCategory("adresant");
		userCat1.create();
		userCat2.create();
		Integer userCat_id1 = userCat1.findByName();
		Integer userCat_id2 = userCat2.findByName();
		userCat1.retrieveById(userCat_id1);
		userCat2.retrieveById(userCat_id2);
		userCat1.retrieveAll();
		userCat2.retrieveAll();
		userCat1.update(userCat_id1, "caller");
		userCat2.update(userCat_id2, "teller");
//		userCat1.deleteAll();
//		userCat2.deleteAll();
		
		User user1 = new User("Vincent Law", userCat_id1);
		User user2 = new User("Re-l Mayer", userCat_id2);
		user1.create(userCat_id1);
		user2.create(userCat_id2);
		Integer user_id1 = user1.findByName();
		Integer user_id2 = user2.findByName();
		user1.retrieveById(user_id1);
		user2.retrieveById(user_id2);
		user1.retrieveAll();
		user2.retrieveAll();
		user1.update("Mabel Pines", user_id1);
		user2.update("Dipper Pines", user_id2);
//		userCat1.deleteAll();
//		userCat2.deleteAll();
		
		Message message1 = new Message("Merry Christmas", userCat_id1, userCat_id2);

		message1.create();
		message1.retrieveAll();
		message1.update(15,"Best wishes", user1.findByName(), user2.findByName());
//		message1.deleteAll();
	}

}
