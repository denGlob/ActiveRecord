/**
 * 
 */
package domain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author Denys Smile
 *
 */
public class UserCategory implements Resourses{
	private String name;
	private Integer id;
	public UserCategory () {}
	public UserCategory (String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	@SuppressWarnings("finally")
	public void retrieveAll() {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM mydb.userCategory");
			while(rs.next()) {
				int id = rs.getInt("ID");
				String name = rs.getString("Name");
				
				System.out.print("ID: "+id+", ");
				System.out.print("Name: "+name+", ");
			}
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();
				rs.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}
	}
	public void retrieveById(Integer id) {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			rs = st.executeQuery("SELECT id, Name FROM mydb.userCategory "
								+ "WHERE id ="+id+";");
			while (rs.next()) {
				int iden = rs.getInt("ID");
				String name = rs.getString("Name");
				
				System.out.print("ID: "+iden+", ");
				System.out.print("Name: "+name+", ");
			}
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();
				rs.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}
	}
	public void update(Integer id, String name) {
		Connection conn = null;
		Statement st = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			st.executeUpdate("UPDATE mydb.userCategory SET name = '"+name
							+"' WHERE id="+id+";");
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}	
	}
	public void delete(Integer id) {
		Connection conn = null;
		Statement st = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			st.executeUpdate("DELETE FROM mydb.userCategory WHERE id="+id+";");
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();

			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}	
	}
	public void deleteAll() {
		Connection conn = null;
		Statement st = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			st.executeUpdate("DELETE FROM mydb.userCategory WHERE id >0;");
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}
	}
	public void create() {
		Connection conn = null;
		Statement st = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			st.executeUpdate("INSERT INTO mydb.userCategory (name) "
							+ "VALUES ('"+getName()+"');");
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
		}
	}
	@SuppressWarnings("finally")
	public Integer findByName() {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		Integer iden =-1;
		try {
			Class.forName(JDBC_DRIVER);
			String kk = getName();
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			st = conn.createStatement();
			rs = st.executeQuery("SELECT id FROM mydb.UserCategory "
								+ "WHERE Name = '"+kk+"';");
			while(rs.next()){
				iden = rs.getInt("ID");
			}
			rs.close();
			return iden;
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				st.close();
			} catch (SQLException se) {
				// TODO Auto-generated catch block
				se.printStackTrace();
			}
			return iden;
		}
	}
}
