/**
 * 
 */
package domain;

/**
 * @author Denys Smile
 *
 */
public interface Resourses {
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	static final String DB_URL = "jdbc:mysql://localhost:3306/mydb";

	static final String USER = "root";
	static final String PASS = "24081991";
}
